tolerance = 0.6

